<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.00
    </div>
    <strong>&copy; <?php echo e(date('Y')); ?> <a href="/"><?php echo e($setting->nama_perusahaan); ?></a>.</strong> All rights
    reserved.
</footer><?php /**PATH C:\xampp\htdocs\all\laravel\PointofSale-Laravel\resources\views/layouts/footer.blade.php ENDPATH**/ ?>