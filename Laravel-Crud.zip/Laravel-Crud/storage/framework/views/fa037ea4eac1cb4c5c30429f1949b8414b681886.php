<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, Crud!</title>
  </head>
  <body>
      <div class="text-center">
        <h1>Crud</h1>
        <p>This is a simple CRUD application.</p>
        <br>
        <a href="<?php echo e(route('create')); ?>">
          <button class="btn btn-md btn-success"> Create</button>
        </a>


      </div>



      <div class="container">
        <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">E-mail</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>

             <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <th scope="row"><?php echo e($loop->iteration); ?></th>
                <td><?php echo e($student->name); ?></td>
                <td><?php echo e($student->email); ?> </td>

                <td>
                    <div class="btn-group">
                      <a href="<?php echo e(route('edit', $student->id)); ?>">
                        <button class="btn btn-md btn-success me-1 p-1">edit</button>
                      </a>

                    <form action="<?php echo e(route('delete')); ?>" method="POST">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="text" name="student_id" value="<?php echo e($student->id); ?>" hidden>
                      <button class="btn btn-md btn-danger  p-1">delete</button>
                </form>


                    </div>
                </td>
              </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>
      </div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\all\laravel\Laravel-Crud\resources\views/index.blade.php ENDPATH**/ ?>