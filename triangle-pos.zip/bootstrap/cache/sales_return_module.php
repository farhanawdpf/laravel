<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SalesReturn\\Providers\\SalesReturnServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SalesReturn\\Providers\\SalesReturnServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);