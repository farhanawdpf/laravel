<footer class="c-footer">
    <div>Triangle Pos © <?php echo e(date('Y')); ?> || Developed by <strong><a target="_blank" href="https://fahimanzam.netlify.app">Fahim Anzam Dip</a></strong></div>

    <div class="mfs-auto d-md-down-none">Version <strong class="text-danger">1.0</strong></div>
</footer>
<?php /**PATH C:\xampp\htdocs\laravel\triangle-pos\resources\views/layouts/footer.blade.php ENDPATH**/ ?>